package com.swvalerian.crud.model;

public enum TeamStatus {
    ACTIVE,
    UNDER_REVIEW,
    DELETED
}
