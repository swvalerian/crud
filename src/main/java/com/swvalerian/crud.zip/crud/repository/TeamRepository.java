package com.swvalerian.crud.repository;

import com.swvalerian.crud.model.Team;

public interface TeamRepository extends GenericRepository<Team, Long> {

}
